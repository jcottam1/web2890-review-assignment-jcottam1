//TODO - Your ES6 JavaScript code (if any) goes here
import 'bootstrap'
var popover = new bootstrap.Popover(document.querySelector('.popover-dismiss'), {
    trigger: 'focus'
  })